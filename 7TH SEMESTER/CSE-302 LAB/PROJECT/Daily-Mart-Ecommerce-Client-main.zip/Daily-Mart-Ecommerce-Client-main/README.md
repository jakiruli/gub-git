# Welcome to my very first full-stack project
## Project name:
# Daily-Mart

Live link: [https://daily-mart-38.web.app/]

## Details info about my project: 
### In this project,you can place order.
### You must have to be logged in to access admin,orders and checkout page
### Here you can log in with google
### Here you can add a product and also remove a product as an admin
### You can check your all order and also ordered date and time
### Thank you
"# Daily-Mart-Ecommerce-Client" 
