const firebaseConfig = {
    apiKey: "AIzaSyCS9DXEZ-roJ6AnRLzRkkDMoS3rlKRnyl8",
    authDomain: "daily-mart-38.firebaseapp.com",
    projectId: "daily-mart-38",
    storageBucket: "daily-mart-38.appspot.com",
    messagingSenderId: "57375865072",
    appId: "1:57375865072:web:9d07b96cbf1a58c4f7ea35"
  };
export default firebaseConfig;