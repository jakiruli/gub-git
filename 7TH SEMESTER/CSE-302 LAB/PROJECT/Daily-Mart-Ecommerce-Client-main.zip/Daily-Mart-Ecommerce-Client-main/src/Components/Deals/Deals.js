import React from 'react';

const Deals = () => {
    return (
        <div className="container">
            <br/>
            <h3>Deals</h3>
            <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Voluptatibus non similique natus, eaque quos distinctio mollitia molestiae minus maiores. Quae, alias suscipit. Excepturi minima odit ratione officia veniam corrupti doloribus repudiandae sed, repellat praesentium numquam ullam vel iusto sit facilis tempore, eaque culpa consequuntur laborum fugiat? Explicabo amet dolorum consequuntur suscipit magnam voluptas, velit praesentium minima quaerat reprehenderit quasi, eligendi odio accusamus. Voluptatem dicta consequuntur, quod culpa in suscipit autem tempore possimus doloribus temporibus blanditiis aliquid non dolor aspernatur dolorum id rem maxime! Officia inventore esse, fugit dignissimos voluptatibus possimus tempora, itaque maxime ut assumenda sint blanditiis impedit doloribus necessitatibus?</p>
            <br/>
            <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Perspiciatis et consequatur perferendis nostrum voluptas fugiat? Deleniti atque fuga rerum corrupti illum eligendi corporis sit officiis, hic esse facere dolore sed ea eius veniam! Corporis iste dignissimos debitis tempore sit possimus quas doloribus aliquam consequuntur mollitia quo delectus atque impedit, temporibus deserunt quae esse modi dicta necessitatibus quasi porro culpa? Praesentium culpa, assumenda ullam possimus, dolore autem dolores hic qui, velit laboriosam ad. Delectus hic dolorem consequuntur exercitationem necessitatibus quos! Consequatur vitae fuga eius nulla ratione nisi dolorum aut explicabo animi eligendi dignissimos expedita in, nobis omnis reprehenderit, et natus nesciunt!</p>
        </div>
    );
};

export default Deals;